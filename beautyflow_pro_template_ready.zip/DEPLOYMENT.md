Deployment steps:

1. Create a GitHub repository (you already have one: beautyflow-ai).
2. Upload these files to the repository root.
3. Connect the repository to Vercel (Import Project -> GitHub -> beautyflow-ai).
4. In Vercel dashboard, set environment variables from `.env.example`.
5. Deploy. The site will be live at your-project.vercel.app
