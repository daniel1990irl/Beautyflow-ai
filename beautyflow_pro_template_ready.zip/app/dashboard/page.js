export default function Dashboard() {
  return (
    <main style={{ padding: 24 }}>
      <h2>Dashboard - BeautyFlow AI</h2>
      <p>Panel inicial para centros de estética. Aquí podrás ver reservas, ingresos y campañas.</p>
    </main>
  )
}
