import Link from 'next/link'

export default function Home() {
  return (
    <main style={{ padding: 32, textAlign: 'center' }}>
      <h1 style={{ fontSize: 36, marginBottom: 8 }}>BeautyFlow AI</h1>
      <p style={{ maxWidth: 720, margin: '0 auto 24px' }}>
        Tu asistente inteligente para centros de estética. Gestión automática, marketing,
        citas y pagos — todo en un solo lugar.
      </p>
      <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
        <Link href="/dashboard">
          <a style={{ padding: '10px 18px', borderRadius: 8, background: '#E7D3C5', color: '#111', textDecoration: 'none' }}>
            Empezar (Demo)
          </a>
        </Link>
        <Link href="/demo">
          <a style={{ padding: '10px 18px', borderRadius: 8, border: '1px solid #ddd', textDecoration: 'none' }}>
            Ver demo
          </a>
        </Link>
      </div>
    </main>
  )
}
