export default function Demo() {
  return (
    <main style={{ padding: 32 }}>
      <h2>Demo: Generador de sugerencias con IA</h2>
      <p>En la versión PRO, aquí llamaremos a la API de IA para generar copys, recordatorios y más.</p>
    </main>
  )
}
