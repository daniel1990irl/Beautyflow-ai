export const metadata = {
  title: "BeautyFlow AI",
  description: "AI Auto-Manager SaaS for beauty centers worldwide",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{ fontFamily: "Inter, Arial, sans-serif", background: "#fff" }}>
        {children}
      </body>
    </html>
  );
}
