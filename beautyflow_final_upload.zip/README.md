# BeautyFlow AI - PRO Template

This is a starter PRO template for the BeautyFlow AI SaaS (Next.js app dir).
It includes:

- Basic landing page
- Dashboard placeholder
- Supabase client example
- .env.example for keys

**How to use**
1. Unzip and upload files to your GitHub repository (or extract locally and push).
2. Create a Supabase project and copy URL + anon key into `.env`.
3. Deploy to Vercel (connect your GitHub repo) and set env vars in Vercel dashboard.
